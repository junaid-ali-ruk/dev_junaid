// spline watermark remove code don't share too much😅

window.onload = function() {
    var shadowRoot = document.querySelector('spline-viewer').shadowRoot;
    shadowRoot.querySelector('#logo').remove();
}